function Contact() {
  return (
    <div style={{ textAlign: "center", padding: "50px 20px" }}>
      <h1>Contact Me</h1>
      <p>Email: ste.lefi@gmail.com</p>
      <p>
        LinkedIn:
        https://www.linkedin.com/in/stephen-francis-chintalapudi-b34588102/
      </p>
      <p>GitHub: https://github.com/whyte-fanggg</p>
    </div>
  )
}

export default Contact
