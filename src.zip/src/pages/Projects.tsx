import ProjectsSection from "../components/ProjectsSection"
// import ProjectMatrix from "../components/ProjectMatrix"
// import MetroGrid from "../components/MetroGrid"

function Projects() {
  return (
    <div>
      <ProjectsSection />
      {/* <ProjectMatrix /> */}
      {/* <MetroGrid /> */}
    </div>
  )
}

export default Projects
